-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jun 26, 2023 at 02:20 PM
-- Server version: 8.0.31
-- PHP Version: 8.0.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dbtravel`
--

-- --------------------------------------------------------

--
-- Table structure for table `laporan`
--

DROP TABLE IF EXISTS `laporan`;
CREATE TABLE IF NOT EXISTS `laporan` (
  `id` varchar(64) NOT NULL,
  `tgl` date NOT NULL,
  `pemasukan` int NOT NULL,
  `pengeluaran` int NOT NULL,
  `ket` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `laporan`
--

INSERT INTO `laporan` (`id`, `tgl`, `pemasukan`, `pengeluaran`, `ket`) VALUES
('001', '2023-06-05', 2000000, 0, 'travel jombang surabaya');

-- --------------------------------------------------------

--
-- Table structure for table `tbdriver`
--

DROP TABLE IF EXISTS `tbdriver`;
CREATE TABLE IF NOT EXISTS `tbdriver` (
  `username` varchar(64) NOT NULL,
  `nama` varchar(64) NOT NULL,
  `nik` varchar(64) NOT NULL,
  `tmplahir` varchar(64) NOT NULL,
  `tgllahir` date NOT NULL,
  `alamat` text NOT NULL,
  `jkel` varchar(64) NOT NULL,
  `usia` varchar(64) NOT NULL,
  `sim` varchar(32) NOT NULL,
  `email` varchar(64) NOT NULL,
  `password` text NOT NULL,
  PRIMARY KEY (`username`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbdriver`
--

INSERT INTO `tbdriver` (`username`, `nama`, `nik`, `tmplahir`, `tgllahir`, `alamat`, `jkel`, `usia`, `sim`, `email`, `password`) VALUES
('agus', 'agus', '21323', 'nganjuk', '2023-06-16', 'kertosono', 'laki laki', '30', '', 'agus@gmail.com', 'qwqe'),
('ahmad123', 'ahmad', '21212', 'nganjuk', '2017-03-08', 'kertosono', 'laki laki', '30', '', 'ahmad@gmail.com', 'null'),
('agus223', 'surabaya', '21323', 'nganjuk', '2023-06-16', 'kertosono', 'laki laki', '30', '', 'agus@gmail.com', 'ww'),
('jono', 'Kediri', '21323', 'nganjuk', '2023-06-19', 'kertosono', 'laki laki', '31', '', 'agus@gmail.com', 'dd'),
('abidin', 'surabaya', '21323', 'nganjuk', '2023-06-30', 'kertosono', 'laki laki', '30', '', 'agus@gmail.com', 'aa'),
('erer', 'adi', '21323', 'nganjuk', '2023-06-21', 'kertosono', 'laki laki', '30', '', 'agus@gmail.com', 'ddd'),
('ilham', 'surabaya', '21323', 'nganjuk', '2023-06-22', 'kertosono', 'laki laki', '30', '', 'agus@gmail.com', 'aa'),
('zaenal', 'cjdw', '132565747', 'sss', '2018-06-22', 'kertosono', 'laki laki', '11', '', 'agus@gmail.com', 'qwweet'),
('wertwaetwe', 'wtwetwet', 'etwetgwetw3', '3tr2wt33wt', '2023-06-02', 'wq3rw3r', '3tr23tr', '32tw235t34t', '', '346', '3yt34yt34yt'),
('agus2221', 'cjdw', '21323', 'nganjuk', '2023-06-23', 'kertosono', 'laki laki', '30', '', 'ahmad@gmail.com', 'ww'),
('2323', 'surabaya', 'ss', 'nganjuk', '2023-06-21', 'kertosono', 'ss', '30', '', 'ahmad@gmail.com', 'ss'),
('s', 'wtwetwet', 'etwetgwetw3', '3tr2wt33wt', '2023-06-15', 'wq3rw3r', '3tr23tr', '21', '', 'a', 'a'),
('sxd', 'wtwetwet', 'etwetgwetw3', '3tr2wt33wt', '2023-06-15', 'wq3rw3r', '3tr23tr', '21', '1.png', 'a', 'x'),
('wertwaetwess', 'wtwetwet', 'etwetgwetw3', '3tr2wt33wt', '2023-06-22', 'wq3rw3r', 's', 's12', '1.png', 'fahmisumatra@gmail.com', '11'),
('test', 'wtwetwet', 'etwetgwetw3', '3tr2wt33wt', '2023-06-16', 'wq3rw3r', '3tr23tr', '32tw235t34t', '1.png', 'fahmisumatra@gmail.com', 'q'),
('test1', 'wtwetwet', 'etwetgwetw3', '3tr2wt33wt', '2023-06-19', 'wq3rw3r', '3tr23tr', '21', '1.png', 'fahmisumatra@gmail.com', 'q'),
('user1', 'wtwetwet', 'etwetgwetw3', '3tr2wt33wt', '2023-06-08', 'wq3rw3r', '3tr23tr', '32tw235t34t', '2.png', 'fahmisumatra@gmail.com', 's');

-- --------------------------------------------------------

--
-- Table structure for table `tbtrans`
--

DROP TABLE IF EXISTS `tbtrans`;
CREATE TABLE IF NOT EXISTS `tbtrans` (
  `id` varchar(64) NOT NULL,
  `namaken` text NOT NULL,
  `jken` varchar(64) NOT NULL,
  `nopol` varchar(64) NOT NULL,
  `bpkb` varchar(64) NOT NULL,
  `stnk` varchar(32) NOT NULL,
  `kapasitas` int NOT NULL,
  `thpajak` date NOT NULL,
  `gambar` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbtrans`
--

INSERT INTO `tbtrans` (`id`, `namaken`, `jken`, `nopol`, `bpkb`, `stnk`, `kapasitas`, `thpajak`, `gambar`) VALUES
('001', 'xenia 2013', 'mobil', 'ag 7676 akj', '', '', 3, '2023-06-15', ''),
('sxd', 'a', 'a', 'a', '1.png', '2.png', 2, '0000-00-00', ''),
('wertwaetwess', '11111ww', 'a', 'a', '1.png', '2.png', 12, '0000-00-00', ''),
('test', 'a1', 'a', 'a', '2.png', '2.png', 12, '0000-00-00', ''),
('test1', 'a2', 'a', 'a', '2.png', '2.png', 12313, '2023-06-16', '2.png'),
('user1', 'xenia21', 'a', 'a', '2.png', '2.png', 43, '2023-06-16', '2.png');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE IF NOT EXISTS `user` (
  `username` varchar(64) NOT NULL,
  `password` varchar(64) NOT NULL,
  `level` varchar(64) NOT NULL,
  PRIMARY KEY (`username`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
